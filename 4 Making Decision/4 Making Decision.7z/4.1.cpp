#include <iostream>
using namespace std;

int main () {
    int x;
    cout << "Enter your number: ";
    cin >> x;

    if (x>0) 
    {
        cout << "This condition is true";
    }

    return 0;
}